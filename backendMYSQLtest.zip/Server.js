const express = require('./node_modules/express');
app = express();
bodyParser = require('./node_modules/body-parser');
port = process.env.PORT || 3000;

const mysql = require('./node_modules/mysql');
// connection configurations
const mc = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'jkseo',
    database: 'partdb'
});
 
// connect to database
mc.connect();

app.listen(port);

console.log('API server started on: ' + port);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var routes = require('./routes/appRoutes'); //importing route
routes(app); //register the route